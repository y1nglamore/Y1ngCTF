<?php
$secret_waf = '/f|\(|\)|and|or|&|\||\^|\$|#|\*|`|\`|;|\/|\\\|"|\"|\ |et|sy|exec|include|\'|\\\'/i';
?>


